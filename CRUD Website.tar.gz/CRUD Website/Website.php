<!doctype html>
<html>
    <head>
        <title>Calculator</title>
        <style>
body {
    background-image: url("hi.jpg");
}
</style>
    </head>
<body>
    <center> 
        <h1> Calculator </h1>
        <p>Select 1st and 2nd Numbers Then Operation</p>
    </center>
        <table width= "250" border = "1" cellpadding = '1' cellspacing= '1' >
            <tr> 
            <th> History of Calculator</th>
            <tr>
</body>



<?php 
// LOG IN
require_once '../login.php';
$mysqli = new mysqli($host, $username, $password, $dbname);
if ($mysqli->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// CALCULAOTR
$result = "";
class calculator
{
    var $a;
    var $b;

    function checkopration($oprator)
    {
        switch($oprator)
        {
            case '+':
            return $this->a + $this->b;
            break;

            case '-':
            return $this->a - $this->b;
            break;

            case '*':
            return $this->a * $this->b;
            break;

            case '/':
            return $this->a / $this->b;
            break;

            default:
            return "Sorry No command found";
        }   
    }
    function getresult($a, $b, $c)
    {
        $this->a = $a;
        $this->b = $b;
        
        return $this->checkopration($c);
    }
}

$cal = new calculator();
if(isset($_POST['submit']))
{   
    $result = $cal->getresult($_POST['n1'],$_POST['n2'],$_POST['op']);
}


// INSERTS DATA INTO TABLE

	$statement = $mysqli->prepare("INSERT INTO Calculator (History) VALUES(?)"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param('s', $result); //bind value
		if($statement->execute())
			{
				//print output text
				echo nl2br("");
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}
// DISPLAY TABLE 
mysql_connect($host, $username, $password)
    or die ('MySQL Not found // Could Not Connect.');
    
mysql_select_db('Website');

$sql = "SELECT * FROM Calculator";
//$records = $mysqli->query($sql);
$records = mysql_query($sql);

echo "<table>";

while($row = mysql_fetch_assoc($records)){   
//while($row = $records->fetch_assoc()) 
    
    echo "<tr>";
    echo "<td> ".$row['History'] . "</td>";
    // echo"<tr><td>" . $row['History'] . "</td> </tr>
    echo "</tr>";
    
}//end while    
    echo "</table>";
?>

<form method="post">
<table align="center">
    <tr>
        <td><strong><?php echo $result; ?><strong></td>
    </tr>
    <tr>
        <td> Select 1st number </td>
        <td><input type="text" name="n1"></td>
    </tr>

    <tr>
        <td>Select 2nd Number</td>
        <td><input type="text" name="n2"></td>
    </tr>

    <tr>
        <td>Select Operator</td>
        <td><select name="op">
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="*">*</option>
            <option value="/">/</option>
        </select></td>
    </tr>

    <tr>
        <td></td>
        <td><input type="submit" name="submit" value="                =                "></td>
    </tr>

</table>
</form
</BODY>
</html>
